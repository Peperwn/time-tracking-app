
from flask import Flask, request, jsonify, render_template
from datetime import datetime
import sqlite3

app = Flask(__name__)

# Δημιουργία βάσης δεδομένων
def init_db():
    conn = sqlite3.connect('time_tracking.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_name TEXT NOT NULL,
            action TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Αρχική σελίδα
@app.route('/')
def index():
    return render_template('index.html')

# Καταγραφή εισόδου/εξόδου
@app.route('/log', methods=['POST'])
def log_time():
    employee_name = request.form.get('employee_name')
    action = request.form.get('action')
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    if not employee_name or not action:
        return jsonify({'error': 'Όνομα εργαζομένου και δράση είναι υποχρεωτικά!'}), 400

    conn = sqlite3.connect('time_tracking.db')
    c = conn.cursor()
    c.execute('INSERT INTO records (employee_name, action, timestamp) VALUES (?, ?, ?)',
              (employee_name, action, timestamp))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Η καταγραφή ολοκληρώθηκε επιτυχώς!'})

# Προβολή αναφορών
@app.route('/reports', methods=['GET'])
def get_reports():
    conn = sqlite3.connect('time_tracking.db')
    c = conn.cursor()
    c.execute('SELECT * FROM records ORDER BY timestamp DESC')
    records = c.fetchall()
    conn.close()
    return render_template('reports.html', records=records)

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host="0.0.0.0")
